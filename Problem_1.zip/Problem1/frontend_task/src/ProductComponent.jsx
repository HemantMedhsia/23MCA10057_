import React from 'react';

const ProductComponent = ({ productName, price, rating, discount, availability }) => {
  return (
    <div>
      <h3>{productName}</h3>
      <p>Price: ${price}</p>
      <p>Rating: {rating}</p>
      <p>Discount: {discount}%</p>
      <p>Availability: {availability ? 'Yes' : 'Out of stock'}</p>
    </div>
  );
};

export default ProductComponent;
