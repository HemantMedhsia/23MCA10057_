import React, { useEffect, useState } from 'react';
import { fetchProducts } from './api';
import ProductComponent from './ProductComponent';

// Default JSON data for placeholder products
const defaultProducts = [
  { productName: 'Placeholder Product 1', price: 100, rating: 4.5, discount: 10, availability: true },
  { productName: 'Placeholder Product 2', price: 200, rating: 4.0, discount: 15, availability: true },
  // Add more placeholder products as needed
];

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const data = await fetchProducts('AMZ', 'Laptop', 1, 10000, 10);
        setProducts(data);
      } catch (error) {
        console.error('Error fetching products:', error);
        // Use default JSON data when API call fails
        setProducts(defaultProducts);
      }
    }
    fetchData();
  }, []);

  return (
    <div>
      <h1>Top 10 Laptops</h1>
      {products.map((product, index) => (
        <ProductComponent key={index} {...product} />
      ))}
    </div>
  );
}

export default App;
