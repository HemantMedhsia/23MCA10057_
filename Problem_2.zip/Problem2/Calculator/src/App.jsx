import React, { useState } from 'react';
import axios from 'axios';
import './App.css'; // Import CSS file for styling

const API_URL = 'http://localhost:9676/numbers/';

function App() {
  const [filterType, setFilterType] = useState('');
  const [responses, setResponses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleFilterTypeChange = (event) => {
    setFilterType(event.target.value);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(getApiUrl(filterType));
      setResponses([...responses, response.data]);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const getApiUrl = (filterType) => {
    switch (filterType) {
      case 'p':
        return 'http://20.244.56.144/test/primes';
      case 'f':
        return 'http://20.244.56.144/test/fibo';
      // Add cases for other filter types as needed
      default:
        return '';
    }
  };

  return (
    <div className="container">
      <h1 className="title">Average Calculator</h1>
      <div className="input-container">
        <label className="label">
          Select Filter Type:
          <select className="select" value={filterType} onChange={handleFilterTypeChange}>
            <option value="">Select</option>
            <option value="p">Prime</option>
            <option value="f">Fibonacci</option>
            {/* Add more options as needed */}
          </select>
        </label>
        <button className="button" onClick={handleSubmit} disabled={!filterType || loading}>
          Calculate Average
        </button>
      </div>
      {loading && <p>Loading...</p>}
      {error && <p className="error">Error: {error}</p>}
      {responses.map((response, index) => (
        <div key={index} className="response">
          <h2>Response {index + 1}</h2>
          <p>Previous State: {JSON.stringify(response.windowPrevState)}</p>
          <p>Current State: {JSON.stringify(response.windowCurrState)}</p>
          <p>Numbers: {JSON.stringify(response.numbers)}</p>
          <p>Average: {response.avg}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
